from django.contrib import admin
from .models import Album, Post, UserProfile, Blogpost, Slide

# Register models with admin site
admin.site.register(Album)
admin.site.register(Post)
admin.site.register(Blogpost)
admin.site.register(Slide)  # Ensure Slide model is registered

class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user',)  # Adjust based on actual fields
    search_fields = ('user__username',)

class SlideAdmin(admin.ModelAdmin):
    list_display = ('id', 'caption', 'image')
